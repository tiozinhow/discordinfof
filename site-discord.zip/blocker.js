mode = 1;
document.oncontextmenu = new Function("return false;")

window.onkeydown = getKey;